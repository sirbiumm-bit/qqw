@echo off
cd /d "%~dp0"
py -3 server.py
if errorlevel 1 (
  echo.
  echo Не удалось запустить сервер. Убедись, что установлен Python 3.
  pause
)
