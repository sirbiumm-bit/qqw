#!/usr/bin/env python3
"""Taskly local web server with individual accounts and private task lists."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, unquote
import hashlib, hmac, json, os, re, secrets, sqlite3, time, socket

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / 'taskly.db'
HOST = '0.0.0.0'
PREFERRED_PORT = int(os.environ.get('TASKLY_PORT', '8080'))
PORT = PREFERRED_PORT
SESSION_SECONDS = 60 * 60 * 24 * 14

def connect_db():
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect_db() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            username TEXT UNIQUE COLLATE NOCASE,
            is_admin INTEGER NOT NULL DEFAULT 0,
            password_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at INTEGER NOT NULL
        )''')
        # Migrate databases created by older Taskly versions.
        cols = {r['name'] for r in db.execute('PRAGMA table_info(users)').fetchall()}
        if 'username' not in cols:
            db.execute('ALTER TABLE users ADD COLUMN username TEXT')
        if 'is_admin' not in cols:
            db.execute('ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0')
        db.execute('CREATE UNIQUE INDEX IF NOT EXISTS users_username_unique ON users(username COLLATE NOCASE)')
        db.execute('''CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            task_json TEXT NOT NULL
        )''')
        # Seed the administrator account on the server only; credentials are never sent to browsers.
        admin = db.execute('SELECT id FROM users WHERE username=? COLLATE NOCASE', ('boford',)).fetchone()
        if not admin:
            db.execute('INSERT INTO users(name,email,username,is_admin,password_hash,created_at) VALUES(?,?,?,?,?,?)',
                       ('Администратор','admin@taskly.local','boford',1,hash_password('boford2007'),int(time.time())))
        else:
            db.execute('UPDATE users SET is_admin=1 WHERE username=? COLLATE NOCASE', ('boford',))

def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 310000)
    return salt.hex() + '$' + digest.hex()

def verify_password(password, stored):
    try:
        salt_hex, expected = stored.split('$', 1)
        actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt_hex), 310000).hex()
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, fmt, *args):
        print('[Taskly] ' + (fmt % args))

    def send_json(self, status, payload, extra_headers=None):
        raw = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        if extra_headers:
            for key, value in extra_headers:
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length > 1_000_000:
                raise ValueError('Слишком большой запрос')
            return json.loads(self.rfile.read(length).decode('utf-8')) if length else {}
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError('Проверь данные формы и попробуй ещё раз')

    def current_user(self):
        cookie = self.headers.get('Cookie', '')
        token = None
        for item in cookie.split(';'):
            key, sep, value = item.strip().partition('=')
            if key == 'taskly_session' and sep:
                token = value
                break
        if not token:
            return None
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        now = int(time.time())
        with connect_db() as db:
            row = db.execute('''SELECT users.id, users.name, users.email, users.username, users.is_admin FROM sessions
                JOIN users ON users.id=sessions.user_id WHERE sessions.token_hash=? AND sessions.expires_at>?''', (token_hash, now)).fetchone()
            if row:
                return dict(row)
            db.execute('DELETE FROM sessions WHERE expires_at<=?', (now,))
        return None

    def make_session(self, user_id):
        token = secrets.token_urlsafe(36)
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with connect_db() as db:
            db.execute('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)', (token_hash, user_id, int(time.time()) + SESSION_SECONDS))
        # Secure is intentionally omitted for LAN HTTP. Use HTTPS before exposing this server to the public internet.
        return ('Set-Cookie', f'taskly_session={token}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_SECONDS}')

    def do_GET(self):
        path = urlparse(self.path).path
        if path.startswith('/api/'):
            user = self.current_user()
            if path == '/api/me':
                return self.send_json(200, {'user': user})
            if not user:
                return self.send_json(401, {'error': 'Сначала войди в аккаунт'})
            if path == '/api/admin/users':
                if not user.get('is_admin'): return self.send_json(403, {'error':'Доступ запрещён'})
                with connect_db() as db:
                    rows = db.execute('SELECT id,name,email,username,created_at FROM users ORDER BY created_at DESC').fetchall()
                    task_counts = {r['user_id']:r['n'] for r in db.execute('SELECT user_id,COUNT(*) n FROM tasks GROUP BY user_id').fetchall()}
                return self.send_json(200, {'users':[dict(r, task_count=task_counts.get(r['id'],0)) for r in rows]})
            if path == '/api/tasks':
                with connect_db() as db:
                    rows = db.execute('SELECT task_json FROM tasks WHERE user_id=?', (user['id'],)).fetchall()
                tasks=[]
                for row in rows:
                    try: tasks.append(json.loads(row['task_json']))
                    except json.JSONDecodeError: pass
                return self.send_json(200, {'tasks': tasks})
            return self.send_json(404, {'error': 'Не найдено'})
        if path == '/':
            self.path = '/index.html'
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path not in ('/api/register', '/api/login', '/api/logout', '/api/share'):
            return self.send_json(404, {'error': 'Не найдено'})
        try:
            data = self.read_json()
        except ValueError as e:
            return self.send_json(400, {'error': str(e)})
        if path == '/api/share':
            user = self.current_user()
            if not user: return self.send_json(401, {'error':'Сначала войди в аккаунт'})
            task = data.get('task'); recipient_name = str(data.get('username','')).strip()
            if not isinstance(task, dict) or not isinstance(task.get('title'), str) or not task.get('title','').strip():
                return self.send_json(400, {'error':'Некорректная задача'})
            if not recipient_name or recipient_name.lower() == str(user.get('username','')).lower():
                return self.send_json(400, {'error':'Укажи логин другого пользователя'})
            with connect_db() as db:
                recipient = db.execute('SELECT id,username FROM users WHERE username=? COLLATE NOCASE', (recipient_name,)).fetchone()
                if not recipient: return self.send_json(404, {'error':'Пользователь с таким логином не найден'})
                copied = dict(task); copied['id'] = secrets.token_urlsafe(12); copied['done'] = False
                copied['sharedFrom'] = user.get('username') or user.get('name')
                db.execute('INSERT INTO tasks(id,user_id,task_json) VALUES(?,?,?)', (copied['id'], recipient['id'], json.dumps(copied,ensure_ascii=False,separators=(',',':'))))
            return self.send_json(200, {'ok':True,'recipient':recipient['username']})
        if path == '/api/logout':
            cookie = self.headers.get('Cookie', '')
            token = next((part.strip().split('=',1)[1] for part in cookie.split(';') if part.strip().startswith('taskly_session=')), None)
            if token:
                with connect_db() as db:
                    db.execute('DELETE FROM sessions WHERE token_hash=?', (hashlib.sha256(token.encode()).hexdigest(),))
            return self.send_json(200, {'ok': True}, [('Set-Cookie','taskly_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0')])
        identifier = str(data.get('identifier', data.get('email',''))).strip()
        email = str(data.get('email','')).strip().lower()
        password = data.get('password','')
        if not isinstance(password, str): return self.send_json(400, {'error':'Проверь пароль'})
        if path == '/api/register':
            name = str(data.get('name','')).strip()
            username = str(data.get('username','')).strip().lower()
            if not name or len(name)>60: return self.send_json(400, {'error':'Введи имя длиной до 60 символов'})
            if not re.fullmatch(r'[a-zA-Z0-9_]{3,24}', username): return self.send_json(400, {'error':'Логин: 3–24 символа, латинские буквы, цифры или _'})
            if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or len(email)>254: return self.send_json(400, {'error':'Введи корректный email'})
            if len(password)<8 or len(password)>128: return self.send_json(400, {'error':'Пароль должен содержать от 8 до 128 символов'})
            try:
                with connect_db() as db:
                    cur = db.execute('INSERT INTO users(name,email,username,is_admin,password_hash,created_at) VALUES(?,?,?,?,?,?)', (name,email,username,0,hash_password(password),int(time.time())))
                    user_id = cur.lastrowid
            except sqlite3.IntegrityError:
                return self.send_json(409, {'error':'Этот email или логин уже занят'})
        else:
            with connect_db() as db:
                row = db.execute('SELECT id,name,email,username,is_admin,password_hash FROM users WHERE email=? COLLATE NOCASE OR username=? COLLATE NOCASE', (identifier,identifier)).fetchone()
            if not row or not verify_password(password, row['password_hash']): return self.send_json(401, {'error':'Неверный логин/email или пароль'})
            user_id = row['id']
        with connect_db() as db:
            row = db.execute('SELECT id,name,email,username,is_admin FROM users WHERE id=?', (user_id,)).fetchone()
        return self.send_json(200, {'user':dict(row)}, [self.make_session(user_id)])

    def do_PUT(self):
        path = urlparse(self.path).path
        if path != '/api/tasks':
            return self.send_json(404, {'error':'Не найдено'})
        user = self.current_user()
        if not user:
            return self.send_json(401, {'error':'Сессия истекла. Войди снова.'})
        try:
            data = self.read_json()
        except ValueError as e:
            return self.send_json(400, {'error':str(e)})
        if not isinstance(data, list) or len(data)>10000:
            return self.send_json(400, {'error':'Некорректный список задач'})
        clean=[]
        seen=set()
        for task in data:
            if not isinstance(task, dict): continue
            task_id=task.get('id'); title=task.get('title')
            if not isinstance(task_id,str) or not task_id or len(task_id)>100 or task_id in seen: continue
            if not isinstance(title,str) or not title.strip() or len(title)>120: continue
            seen.add(task_id)
            clean.append((task_id,user['id'],json.dumps(task,ensure_ascii=False,separators=(',',':'))))
        with connect_db() as db:
            db.execute('DELETE FROM tasks WHERE user_id=?', (user['id'],))
            db.executemany('INSERT INTO tasks(id,user_id,task_json) VALUES(?,?,?)', clean)
        return self.send_json(200, {'ok':True,'count':len(clean)})

if __name__ == '__main__':
    init_db()
    # If an older static server is still running on 8080, automatically choose the next free port.
    httpd = None
    for candidate in [PREFERRED_PORT] + [p for p in range(PREFERRED_PORT + 1, PREFERRED_PORT + 21)]:
        try:
            httpd = ThreadingHTTPServer((HOST, candidate), Handler)
            PORT = candidate
            break
        except OSError:
            continue
    if httpd is None:
        raise SystemExit(f'Не удалось найти свободный порт начиная с {PREFERRED_PORT}. Закрой другие серверы и повтори запуск.')
    print(f'Taskly запущен: http://127.0.0.1:{PORT}', flush=True)
    print(f'В локальной сети открой http://172.16.130.66:{PORT} (если это IP этого компьютера).', flush=True)
    print('Для остановки нажми Ctrl+C. Не выставляй этот HTTP-сервер напрямую в интернет.', flush=True)
    httpd.serve_forever()
